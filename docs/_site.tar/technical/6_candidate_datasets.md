---
order: 6
---

# Candidate Datasets

## OpenNeuro resting-state EEG datasets:

1. ds004024
2. ds003947
3. ds003768
4. ds003574
5. ds002778 (Parkinson)
6. ds002158
7. ds004584
8. ds004511
9. ds003944
10. ds003800
11. ds003490 (Parkinson)
12. ds003478